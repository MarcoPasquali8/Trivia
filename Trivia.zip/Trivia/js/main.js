import * as THREE from 'three';
import {Wheel} from './wheel.js';

let renderer = null;
let scene = null;
let camera = null;
let clock;

let width;
let height;

let wheel = null;
let circle = null;
let pointer = null;



function initScene(){
    if(renderer != null) return;

    width = document.getElementById("threejs").clientWidth;
    height = document.getElementById("threejs").clientHeight;

    renderer = new THREE.WebGLRenderer({antialias: "true", powerPreference: "high-performance", canvas: document.getElementById("threejs")});
    renderer.setSize(width, height);

    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x00FFFF);

    camera = new THREE.PerspectiveCamera(50, width/height, 1, 10);
    camera.position.set(0, 0, 0);
    camera.lookAt(new THREE.Vector3(0, 0, 5));

    clock = new THREE.Clock();

    wheel = new Wheel(scene);

    let geometry = new THREE.CircleGeometry(0.4);
    let material = new THREE.MeshBasicMaterial({color: 0x888888, side: THREE.DoubleSide});
    circle = new THREE.Mesh(geometry, material);
    circle.position.z = 5;
    scene.add(circle);

    geometry = new THREE.ConeGeometry(0.2, 1, 4);
    pointer = new THREE.Mesh(geometry, material);
    pointer.position.z = 5;
    pointer.position.y = 0.2;
    scene.add(pointer);

    renderer.setAnimationLoop(animate);
    renderer.domElement.addEventListener('click', onClick);
}


function animate(){
    if(wheel.isClickable){
        renderer.domElement.addEventListener('click', onClick);
    }
    renderer.render(scene, camera);
}


function onClick(){
    renderer.domElement.removeEventListener('click', onClick);
    wheel.clock = new THREE.Clock();
    wheel.time = 0;
    wheel.speed = 5;
    wheel.extraTime = Math.random();
    wheel.spin();
}

window.onload = initScene;