let quiz;
let entertainmentCategories = [10, 11, 12, 13, 14, 15, 16, 29, 31, 32];
let scienceCategories = [17, 18, 19, 30];
let score = 0;
let bestScore = 0;
let givenAnswer = false;
let gameOver = false;

function getQuiz(category){
    document.getElementById("threejs").style.display = "none";
    document.getElementById("quizBoard").style.display = "block";

    if(category == 0){
        document.getElementById("quiz").innerHTML += '<label id="question">Scegli la tua categoria</label>' + 
                                                    '<div id="storia" onclick="fetchQuiz(23);"><p>Storia</p></div>' + 
                                                    '<div id="sport" onclick="fetchQuiz(21);"><p>Sport</p></div>' + 
                                                    '<div id="arte" onclick="fetchQuiz(25);"><p>Arte</p></div>' + 
                                                    '<div id="intrattenimento" onclick="fetchQuiz(entertainmentCategories[Math.floor(Math.random()*10)]);"><p>Intrattenimento</p></div>' + 
                                                    '<div id="geografia" onclick="fetchQuiz(22);"><p>Geografia</p></div>' + 
                                                    '<div id="scienze" onclick="fetchQuiz(scienceCategories[Math.floor(Math.random()*4)]);"><p>Scienze</p></div>';
    }else{
        fetchQuiz(category);
    }
}


function fetchQuiz(category){
    document.getElementById("quiz").innerHTML = "";
    fetch('https://opentdb.com/api.php?amount=1&category=' + category)
        .then((response) => response.json())
        .then((data) => {
            quiz = new Quiz(data);
            quiz.updateDisplay();
        })
        .catch(error => fetchQuiz(category));
}


function countDown(timeCount){
    document.getElementById("timer").innerHTML = "time left: " + timeCount;
    if(!givenAnswer){
        if(timeCount == 0){
            revealAnswers(5);
        }else{
            setTimeout(() => countDown(timeCount-1), 1000);
        }
    }
}


function revealAnswers(selectedAnswer){
    if(givenAnswer){
        return;
    }
    givenAnswer = true;
    if(selectedAnswer == 5){
        for(let i = 0; i < quiz.incorrectAnswers.length+1; i++){
            document.getElementById("option" + (i+1)).style.backgroundColor = "red";
        }
        gameOver = true;
    }else{
        if(document.getElementById("answer" + selectedAnswer).innerHTML == quiz.correctAnswer){
            document.getElementById("option" + selectedAnswer).style.backgroundColor = "green";
            if(quiz.difficulty == "easy"){
                score += 1000;
            }else if(quiz.difficulty == "medium"){
                score += 2000;
            }else{
                score += 3000;
            }
            if(score > bestScore){
                bestScore = score;
            }
        }else{
            document.getElementById("option" + (selectedAnswer)).style.backgroundColor = "red";
            gameOver = true;
        }
    }
    document.getElementById("score").innerHTML = "Score: " + score;

    setTimeout(() => {endGame()}, 3000);
}


function endGame(){
    if(gameOver){
        document.getElementById("quiz").innerHTML = "<label id='question'>YOU LOST!</label><label id='question'>Your score is " + score + "</label><label id='question'>Your best score is " + bestScore + "</label>";
        score = 0;
        setTimeout(() => endQuiz(), 5000);
        gameOver = false;
    }else{
        endQuiz();
    }
}


function endQuiz(){
    document.getElementById("threejs").style.display = "block";
    document.getElementById("quizBoard").style.display = "none";
    document.getElementById("quiz").innerHTML = "";
}


class Quiz{
    constructor(data){
        this.question = data.results[0].question;
        this.correctAnswer = data.results[0].correct_answer;
        this.incorrectAnswers = data.results[0].incorrect_answers;
        this.difficulty = data.results[0].difficulty;
        this.category = data.results[0].category;
    }


    updateDisplay(){
        document.getElementById('quiz').innerHTML += '<label id="info">Category: ' + this.category + ', Difficulty: ' + this.difficulty + '</label>';
        document.getElementById('quiz').innerHTML += '<label id="question">' + this.question + "</label>";

        let positionCorrectAnswer = parseInt(Math.random()*(this.incorrectAnswers.length+1));
        let cur = 0;
        for(let i = 0; i < this.incorrectAnswers.length+1; i++){
            if(i == positionCorrectAnswer){
                if(i%2 == 0){
                    document.getElementById('quiz').innerHTML += '<div class="optionLeft" id="option' + (i+1) + '" onclick="revealAnswers(' + (i+1) + ');"><p id="answer' + (i+1) + '">' + this.correctAnswer + '</p></div>';
                }else{
                    document.getElementById('quiz').innerHTML += '<div class="optionRight" id="option' + (i+1) + '" onclick="revealAnswers(' + (i+1) + ');"><p id="answer' + (i+1) + '">' + this.correctAnswer + '</p></div>';
                }
            }else{
                if(i%2 == 0){
                    document.getElementById('quiz').innerHTML += '<div class="optionLeft" id="option' + (i+1) + '" onclick="revealAnswers(' + (i+1) + ');"><p id="answer' + (i+1) + '">' + this.incorrectAnswers[cur] + '</p></div>';
                }else{
                    document.getElementById('quiz').innerHTML += '<div class="optionRight" id="option' + (i+1) + '" onclick="revealAnswers(' + (i+1) + ');"><p id="answer' + (i+1) + '">' + this.incorrectAnswers[cur] + '</p></div>';
                }
                cur++;
            }
        }
        givenAnswer = false;
        countDown(10);
    }
}