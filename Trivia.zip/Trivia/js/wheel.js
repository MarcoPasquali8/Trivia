import * as THREE from 'three';
import * as QUIZ from './quiz.js';

class Wheel extends THREE.Group{
    constructor(scene){
        super();

        let circleGeometry;
        let circleMaterial;
        let circle;

        for(let i = 0; i < 7; i++){
            circleGeometry = new THREE.CircleGeometry(1, 32, Math.PI*2/7*i, Math.PI*2/7);
            switch(i){
                case 0:
                    circleMaterial = new THREE.MeshBasicMaterial({color: 0xFFFF00, side: THREE.DoubleSide});
                    break;
                case 1:
                    circleMaterial = new THREE.MeshBasicMaterial({color: 0xFF8800, side: THREE.DoubleSide});
                    break;
                case 2:
                    circleMaterial = new THREE.MeshBasicMaterial({color: 0xFF0000, side: THREE.DoubleSide});
                    break;
                case 3:
                    circleMaterial = new THREE.MeshBasicMaterial({color: 0xFF00FF, side: THREE.DoubleSide});
                    break;
                case 4:
                    circleMaterial = new THREE.MeshBasicMaterial({color: 0x8800FF, side: THREE.DoubleSide});
                    break;
                case 5:
                    circleMaterial = new THREE.MeshBasicMaterial({color: 0x0000FF, side: THREE.DoubleSide});
                    break;
                case 6:
                    circleMaterial = new THREE.MeshBasicMaterial({color: 0x00FF00, side: THREE.DoubleSide});
                    break;
            }
            circle = new THREE.Mesh(circleGeometry, circleMaterial);

            this.add(circle);
        }
        this.clock = new THREE.Clock();
        this.time = 0;
        this.speed = 5;
        this.extraTime = 0;
        this.isClickable = true;

        this.position.z = 5;
        scene.add(this);

        //this.generalKnowledgeCategories = [9];
        this.entertainmentCategories = [10, 11, 12, 13, 14, 15, 16, 29, 31, 32];
        this.scienceCategories = [17, 18, 19, 30];
        //this.mythologyCategories = [20];
        //this.sportsCategories = [21];
        //this.geographyCategories = [22];
        //this.historyCategories = [23];
        //this.politicsCategories = [24];
        //this.artCategories = [25];
        //this.celebritiesCategories = [26];
        //this.animalsCategories = [27];
        //this.vehiclesCategories = [28];
    }


    spin(){
        if(this.speed >= 0){
            this.isClickable = false;
            let dt = this.clock.getDelta();

            this.time += dt;

            if(this.time >= 3+this.extraTime){
                this.speed -= dt;
            }

            this.rotateZ(Math.PI*dt*this.speed);

            requestAnimationFrame(() => this.spin());
        }else{
            setTimeout(() => getQuiz(this.getCategory()), 1000);
            setTimeout(() => this.isClickable = true, 1000);
        }
    }


    getCategory(){
        let rotation = 0;

        if(this.rotation.z >= Math.PI/2){
            rotation = -Math.PI - (Math.PI - this.rotation.z);
        }else{
            rotation = this.rotation.z;
        }

        if(rotation < Math.PI/2 && rotation >= Math.PI/2 - Math.PI*2/7){
            console.log("giallo");
            return 23;
        }else if(rotation < Math.PI/2 - Math.PI*2/7 && rotation >= Math.PI/2 - Math.PI*2/7*2){
            console.log("arancione");
            return 21;
        }else if(rotation < Math.PI/2 - Math.PI*2/7*2 && rotation >= Math.PI/2 - Math.PI*2/7*3){
            console.log("rosso");
            return 25;
        }else if(rotation < Math.PI/2 - Math.PI*2/7*3 && rotation >= Math.PI/2 - Math.PI*2/7*4){
            console.log("rosa");
            return this.entertainmentCategories[Math.floor(Math.random()*10)];
        }else if(rotation < Math.PI/2 - Math.PI*2/7*4 && rotation >= Math.PI/2 - Math.PI*2/7*5){
            console.log("viola");
            return 0;
        }else if(rotation < Math.PI/2 - Math.PI*2/7*5 && rotation >= Math.PI/2 - Math.PI*2/7*6){
            console.log("blu");
            return 22;
        }else if(rotation < Math.PI/2 - Math.PI*2/7*6 && rotation >= Math.PI/2 - Math.PI*2/7*7){
            console.log("verde");
            return this.scienceCategories[Math.floor(Math.random()*4)];
        }
    }
}

export {Wheel};